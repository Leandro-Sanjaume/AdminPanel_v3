<script lang="ts" setup>
	navigateTo('/login');
</script>
